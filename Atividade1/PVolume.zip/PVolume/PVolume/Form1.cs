﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PVolume
{
    public partial class Form1 : Form
    {
        double raio, altura, volume; /* globais */
        public Form1()
        {
            InitializeComponent();
        }

        private void Txtaltura_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtaltura.Text, out altura))
            {
                MessageBox.Show("Altura inválida");
                txtaltura.Focus();
            }
            else
            {
                if (altura<=0)
                {
                    MessageBox.Show("Altura não pode ser <=0");
                    txtaltura.Focus();
                }
            }
        }

        private void Btncalcular_Click(object sender, EventArgs e)
        {
            volume = Math.PI * Math.Pow(raio, 2) * altura;
            txtvolume.Text = volume.ToString("N2");
        }

        private void Btnfechar_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void Txtraio_Validating(object sender, CancelEventArgs e)
        {
            if (!double.TryParse(txtraio.Text, out raio))
            {
                MessageBox.Show("Raio inválido");
                txtraio.Focus();
            }
            else
            {
                if (raio<=0)
                {
                    MessageBox.Show("Raio não pode ser <=0");
                    txtraio.Focus();
                }
            }
        }
    }
}
