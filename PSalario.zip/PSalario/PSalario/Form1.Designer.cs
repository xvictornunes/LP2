﻿namespace PSalario
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lbl1Nome = new System.Windows.Forms.Label();
            this.lbl2SalB = new System.Windows.Forms.Label();
            this.lbl3Filhos = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.lbl5IRPF = new System.Windows.Forms.Label();
            this.lbl6SalFam = new System.Windows.Forms.Label();
            this.lbl7SalLiq = new System.Windows.Forms.Label();
            this.lbl8DescINSS = new System.Windows.Forms.Label();
            this.lbl9DescIRPF = new System.Windows.Forms.Label();
            this.txtb1Nome = new System.Windows.Forms.TextBox();
            this.txtb2AliqINSS = new System.Windows.Forms.TextBox();
            this.txtb3AliqIRPF = new System.Windows.Forms.TextBox();
            this.txtb4SalFam = new System.Windows.Forms.TextBox();
            this.txtb5SalLiq = new System.Windows.Forms.TextBox();
            this.txtb6DescINSS = new System.Windows.Forms.TextBox();
            this.txtb7DescIRPF = new System.Windows.Forms.TextBox();
            this.btn1Verificar = new System.Windows.Forms.Button();
            this.msktxtb1SalBruto = new System.Windows.Forms.MaskedTextBox();
            this.nuPDFilho = new System.Windows.Forms.NumericUpDown();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.nuPDFilho)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl1Nome
            // 
            this.lbl1Nome.AutoSize = true;
            this.lbl1Nome.Location = new System.Drawing.Point(37, 42);
            this.lbl1Nome.Name = "lbl1Nome";
            this.lbl1Nome.Size = new System.Drawing.Size(35, 13);
            this.lbl1Nome.TabIndex = 0;
            this.lbl1Nome.Text = "Nome";
            // 
            // lbl2SalB
            // 
            this.lbl2SalB.AutoSize = true;
            this.lbl2SalB.Location = new System.Drawing.Point(37, 77);
            this.lbl2SalB.Name = "lbl2SalB";
            this.lbl2SalB.Size = new System.Drawing.Size(70, 13);
            this.lbl2SalB.TabIndex = 1;
            this.lbl2SalB.Text = "Salário Bruto ";
            // 
            // lbl3Filhos
            // 
            this.lbl3Filhos.AutoSize = true;
            this.lbl3Filhos.Location = new System.Drawing.Point(37, 110);
            this.lbl3Filhos.Name = "lbl3Filhos";
            this.lbl3Filhos.Size = new System.Drawing.Size(86, 13);
            this.lbl3Filhos.TabIndex = 2;
            this.lbl3Filhos.Text = "Número de filhos";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Location = new System.Drawing.Point(37, 236);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(73, 13);
            this.lblINSS.TabIndex = 3;
            this.lblINSS.Text = "Aliquota INSS";
            // 
            // lbl5IRPF
            // 
            this.lbl5IRPF.AutoSize = true;
            this.lbl5IRPF.Location = new System.Drawing.Point(37, 278);
            this.lbl5IRPF.Name = "lbl5IRPF";
            this.lbl5IRPF.Size = new System.Drawing.Size(72, 13);
            this.lbl5IRPF.TabIndex = 4;
            this.lbl5IRPF.Text = "Aliquota IRPF";
            // 
            // lbl6SalFam
            // 
            this.lbl6SalFam.AutoSize = true;
            this.lbl6SalFam.Location = new System.Drawing.Point(37, 319);
            this.lbl6SalFam.Name = "lbl6SalFam";
            this.lbl6SalFam.Size = new System.Drawing.Size(76, 13);
            this.lbl6SalFam.TabIndex = 5;
            this.lbl6SalFam.Text = "Salário Família";
            // 
            // lbl7SalLiq
            // 
            this.lbl7SalLiq.AutoSize = true;
            this.lbl7SalLiq.Location = new System.Drawing.Point(37, 367);
            this.lbl7SalLiq.Name = "lbl7SalLiq";
            this.lbl7SalLiq.Size = new System.Drawing.Size(78, 13);
            this.lbl7SalLiq.TabIndex = 6;
            this.lbl7SalLiq.Text = "Salário Líquido";
            // 
            // lbl8DescINSS
            // 
            this.lbl8DescINSS.AutoSize = true;
            this.lbl8DescINSS.Location = new System.Drawing.Point(419, 236);
            this.lbl8DescINSS.Name = "lbl8DescINSS";
            this.lbl8DescINSS.Size = new System.Drawing.Size(81, 13);
            this.lbl8DescINSS.TabIndex = 7;
            this.lbl8DescINSS.Text = "Desconto INSS";
            // 
            // lbl9DescIRPF
            // 
            this.lbl9DescIRPF.AutoSize = true;
            this.lbl9DescIRPF.Location = new System.Drawing.Point(419, 285);
            this.lbl9DescIRPF.Name = "lbl9DescIRPF";
            this.lbl9DescIRPF.Size = new System.Drawing.Size(80, 13);
            this.lbl9DescIRPF.TabIndex = 8;
            this.lbl9DescIRPF.Text = "Desconto IRPF";
            // 
            // txtb1Nome
            // 
            this.txtb1Nome.Location = new System.Drawing.Point(142, 39);
            this.txtb1Nome.Name = "txtb1Nome";
            this.txtb1Nome.Size = new System.Drawing.Size(322, 20);
            this.txtb1Nome.TabIndex = 9;
            this.txtb1Nome.Validating += new System.ComponentModel.CancelEventHandler(this.Txtb1Nome_Validating);
            // 
            // txtb2AliqINSS
            // 
            this.txtb2AliqINSS.Enabled = false;
            this.txtb2AliqINSS.Location = new System.Drawing.Point(142, 229);
            this.txtb2AliqINSS.Name = "txtb2AliqINSS";
            this.txtb2AliqINSS.Size = new System.Drawing.Size(100, 20);
            this.txtb2AliqINSS.TabIndex = 12;
            // 
            // txtb3AliqIRPF
            // 
            this.txtb3AliqIRPF.Enabled = false;
            this.txtb3AliqIRPF.Location = new System.Drawing.Point(142, 275);
            this.txtb3AliqIRPF.Name = "txtb3AliqIRPF";
            this.txtb3AliqIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtb3AliqIRPF.TabIndex = 13;
            // 
            // txtb4SalFam
            // 
            this.txtb4SalFam.Enabled = false;
            this.txtb4SalFam.Location = new System.Drawing.Point(142, 316);
            this.txtb4SalFam.Name = "txtb4SalFam";
            this.txtb4SalFam.Size = new System.Drawing.Size(100, 20);
            this.txtb4SalFam.TabIndex = 14;
            // 
            // txtb5SalLiq
            // 
            this.txtb5SalLiq.Enabled = false;
            this.txtb5SalLiq.Location = new System.Drawing.Point(142, 360);
            this.txtb5SalLiq.Name = "txtb5SalLiq";
            this.txtb5SalLiq.Size = new System.Drawing.Size(100, 20);
            this.txtb5SalLiq.TabIndex = 15;
            // 
            // txtb6DescINSS
            // 
            this.txtb6DescINSS.Enabled = false;
            this.txtb6DescINSS.Location = new System.Drawing.Point(518, 229);
            this.txtb6DescINSS.Name = "txtb6DescINSS";
            this.txtb6DescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtb6DescINSS.TabIndex = 16;
            // 
            // txtb7DescIRPF
            // 
            this.txtb7DescIRPF.Enabled = false;
            this.txtb7DescIRPF.Location = new System.Drawing.Point(518, 278);
            this.txtb7DescIRPF.Name = "txtb7DescIRPF";
            this.txtb7DescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtb7DescIRPF.TabIndex = 17;
            // 
            // btn1Verificar
            // 
            this.btn1Verificar.Location = new System.Drawing.Point(121, 164);
            this.btn1Verificar.Name = "btn1Verificar";
            this.btn1Verificar.Size = new System.Drawing.Size(141, 23);
            this.btn1Verificar.TabIndex = 18;
            this.btn1Verificar.Text = "Verificar Desconto";
            this.btn1Verificar.UseVisualStyleBackColor = true;
            this.btn1Verificar.Click += new System.EventHandler(this.Btn1Verificar_Click);
            // 
            // msktxtb1SalBruto
            // 
            this.msktxtb1SalBruto.Location = new System.Drawing.Point(142, 70);
            this.msktxtb1SalBruto.Mask = "90000.00";
            this.msktxtb1SalBruto.Name = "msktxtb1SalBruto";
            this.msktxtb1SalBruto.Size = new System.Drawing.Size(100, 20);
            this.msktxtb1SalBruto.TabIndex = 19;
            this.msktxtb1SalBruto.Validating += new System.ComponentModel.CancelEventHandler(this.Msktxtb1SalBruto_Validating);
            // 
            // nuPDFilho
            // 
            this.nuPDFilho.Location = new System.Drawing.Point(142, 108);
            this.nuPDFilho.Name = "nuPDFilho";
            this.nuPDFilho.Size = new System.Drawing.Size(120, 20);
            this.nuPDFilho.TabIndex = 20;
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.nuPDFilho);
            this.Controls.Add(this.msktxtb1SalBruto);
            this.Controls.Add(this.btn1Verificar);
            this.Controls.Add(this.txtb7DescIRPF);
            this.Controls.Add(this.txtb6DescINSS);
            this.Controls.Add(this.txtb5SalLiq);
            this.Controls.Add(this.txtb4SalFam);
            this.Controls.Add(this.txtb3AliqIRPF);
            this.Controls.Add(this.txtb2AliqINSS);
            this.Controls.Add(this.txtb1Nome);
            this.Controls.Add(this.lbl9DescIRPF);
            this.Controls.Add(this.lbl8DescINSS);
            this.Controls.Add(this.lbl7SalLiq);
            this.Controls.Add(this.lbl6SalFam);
            this.Controls.Add(this.lbl5IRPF);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lbl3Filhos);
            this.Controls.Add(this.lbl2SalB);
            this.Controls.Add(this.lbl1Nome);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nuPDFilho)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1Nome;
        private System.Windows.Forms.Label lbl2SalB;
        private System.Windows.Forms.Label lbl3Filhos;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.Label lbl5IRPF;
        private System.Windows.Forms.Label lbl6SalFam;
        private System.Windows.Forms.Label lbl7SalLiq;
        private System.Windows.Forms.Label lbl8DescINSS;
        private System.Windows.Forms.Label lbl9DescIRPF;
        private System.Windows.Forms.TextBox txtb1Nome;
        private System.Windows.Forms.TextBox txtb2AliqINSS;
        private System.Windows.Forms.TextBox txtb3AliqIRPF;
        private System.Windows.Forms.TextBox txtb4SalFam;
        private System.Windows.Forms.TextBox txtb5SalLiq;
        private System.Windows.Forms.TextBox txtb6DescINSS;
        private System.Windows.Forms.TextBox txtb7DescIRPF;
        private System.Windows.Forms.Button btn1Verificar;
        private System.Windows.Forms.MaskedTextBox msktxtb1SalBruto;
        private System.Windows.Forms.NumericUpDown nuPDFilho;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
    }
}

