﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PSalario
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Txtb1Nome_Validating(object sender, CancelEventArgs e)
        {
            if (txtb1Nome.Text == "")
            {
                errorProvider1.SetError(txtb1Nome, "Insira o nome!");
            }
            else
            {
                errorProvider1.Clear();
            }            
        }

        private void Msktxtb1SalBruto_Validating(object sender, CancelEventArgs e)
        {
            double salario;
            errorProvider2.SetError(msktxtb1SalBruto, "");

            if (!double.TryParse(msktxtb1SalBruto.Text, out salario) || (salario <= 0))
                {
                errorProvider2.SetError(msktxtb1SalBruto, "O salário deve ser maior que 0!");
                }
        }

        private void Btn1Verificar_Click(object sender, EventArgs e)
        {
            double salBruto, filhos, descontoINSS, descontoIRPF, salFam, salLiquido;
            if (double.TryParse(msktxtb1SalBruto.Text, out salBruto))
            {

                if (salBruto <= 800.47)
                {
                    txtb2AliqINSS.Text = "7,65%";
                    descontoINSS = 0.0765 * salBruto;
                    txtb6DescINSS.Text = descontoINSS.ToString();
                }
                else if (salBruto <= 1050)
                {
                    txtb2AliqINSS.Text = "8,65%";
                    descontoINSS = 0.0865 * salBruto;
                    txtb6DescINSS.Text = descontoINSS.ToString();
                }
                else if (salBruto <= 1400.77)
                {
                    txtb2AliqINSS.Text = "9%";
                    descontoINSS = 0.09 * salBruto;
                    txtb6DescINSS.Text = descontoINSS.ToString();
                }
                else if (salBruto <= 2801.56)
                {
                    txtb2AliqINSS.Text = "11%";
                    descontoINSS = 0.11 * salBruto;
                    txtb6DescINSS.Text = descontoINSS.ToString();
                }
                else
                {
                    txtb2AliqINSS.Text = "Teto";
                    txtb6DescINSS.Text = "308,17";
                }
                if (salBruto <= 1257.12)
                {
                    txtb3AliqIRPF.Text = "Isento";
                    txtb7DescIRPF.Text = "0";
                }
                else if (salBruto <= 2512.08)
                {
                    txtb3AliqIRPF.Text = "15%";
                    descontoIRPF = 0.15 * salBruto;
                    txtb7DescIRPF.Text = descontoIRPF.ToString();
                }
                else if (salBruto > 2512.08)
                {
                    txtb3AliqIRPF.Text = "27,5%";
                    descontoIRPF = 0.275 * salBruto;
                    txtb7DescIRPF.Text = descontoIRPF.ToString();
                }
                if (salBruto <= 435.52)
                {
                    filhos = Convert.ToDouble(nuPDFilho);
                    salFam = filhos * 22.33;
                    txtb4SalFam.Text = salFam.ToString();
                }
                else if (salBruto <= 654.61)
                {
                    filhos = Convert.ToDouble(nuPDFilho);
                    salFam = filhos * 15.74;
                    txtb4SalFam.Text = salFam.ToString();
                }
                else
                {
                    txtb4SalFam.Text = "0";
                }
            }



        }
    }
}
