﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PCalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; //variáveis globais//

        private void Txtnum1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum1.Text, out numero1)) //negação do double//
            {
                MessageBox.Show("Número inválido!");
                txtnum1.Focus(); //voltapara receber número 1//
            }
        }

        private void Txtnum2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtnum2.Text, out numero2))
            {
                MessageBox.Show("Número inválido!");
                txtnum2.Focus();
            }
        }

        private void Btnnum3_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btnnum4_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btnnum5_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtnum3.Text = resultado.ToString();
        }

        private void Btnnum6_Click(object sender, EventArgs e)
        {
            if (numero2 == 0) //não se pode dividir por zero. == significa IGUAL//
            {
                MessageBox.Show("Não se pode dividir por zero!", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error); //personalizando a message box//
                txtnum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtnum3.Text = resultado.ToString();
            }
        }

        private void Btnnum2_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você realmente deseja sair?", "Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Btnnum1_Click(object sender, EventArgs e)
        {
            txtnum1.Clear(); //limpa os botões//
            txtnum2.Clear();
            txtnum3.Clear();
            resultado = 0; //coloca o resultado igual a 0//
            numero1 = 0;
            numero2 = 0;
            txtnum1.Focus(); //volta o foco para o primeiro botão//
        }
    }
}
