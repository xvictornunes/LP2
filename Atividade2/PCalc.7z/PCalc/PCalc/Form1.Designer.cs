﻿namespace PCalc
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtnum1 = new System.Windows.Forms.TextBox();
            this.lblnum1 = new System.Windows.Forms.Label();
            this.btnnum1 = new System.Windows.Forms.Button();
            this.txtnum2 = new System.Windows.Forms.TextBox();
            this.lblnum2 = new System.Windows.Forms.Label();
            this.lblnum3 = new System.Windows.Forms.Label();
            this.btnnum2 = new System.Windows.Forms.Button();
            this.btnnum3 = new System.Windows.Forms.Button();
            this.btnnum4 = new System.Windows.Forms.Button();
            this.btnnum5 = new System.Windows.Forms.Button();
            this.btnnum6 = new System.Windows.Forms.Button();
            this.txtnum3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // txtnum1
            // 
            this.txtnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum1.Location = new System.Drawing.Point(255, 121);
            this.txtnum1.Name = "txtnum1";
            this.txtnum1.Size = new System.Drawing.Size(170, 26);
            this.txtnum1.TabIndex = 0;
            this.txtnum1.Validated += new System.EventHandler(this.Txtnum1_Validated);
            // 
            // lblnum1
            // 
            this.lblnum1.AutoSize = true;
            this.lblnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum1.Location = new System.Drawing.Point(153, 121);
            this.lblnum1.Name = "lblnum1";
            this.lblnum1.Size = new System.Drawing.Size(78, 20);
            this.lblnum1.TabIndex = 1;
            this.lblnum1.Text = "Número 1";
            // 
            // btnnum1
            // 
            this.btnnum1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnum1.Location = new System.Drawing.Point(491, 121);
            this.btnnum1.Name = "btnnum1";
            this.btnnum1.Size = new System.Drawing.Size(145, 63);
            this.btnnum1.TabIndex = 7;
            this.btnnum1.Text = "Limpar";
            this.btnnum1.UseVisualStyleBackColor = true;
            this.btnnum1.Click += new System.EventHandler(this.Btnnum1_Click);
            // 
            // txtnum2
            // 
            this.txtnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum2.Location = new System.Drawing.Point(255, 172);
            this.txtnum2.Name = "txtnum2";
            this.txtnum2.Size = new System.Drawing.Size(170, 26);
            this.txtnum2.TabIndex = 1;
            this.txtnum2.Validated += new System.EventHandler(this.Txtnum2_Validated);
            // 
            // lblnum2
            // 
            this.lblnum2.AutoSize = true;
            this.lblnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum2.Location = new System.Drawing.Point(153, 172);
            this.lblnum2.Name = "lblnum2";
            this.lblnum2.Size = new System.Drawing.Size(78, 20);
            this.lblnum2.TabIndex = 4;
            this.lblnum2.Text = "Número 2";
            // 
            // lblnum3
            // 
            this.lblnum3.AutoSize = true;
            this.lblnum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblnum3.Location = new System.Drawing.Point(153, 217);
            this.lblnum3.Name = "lblnum3";
            this.lblnum3.Size = new System.Drawing.Size(82, 20);
            this.lblnum3.TabIndex = 5;
            this.lblnum3.Text = "Resultado";
            // 
            // btnnum2
            // 
            this.btnnum2.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btnnum2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnum2.Location = new System.Drawing.Point(491, 199);
            this.btnnum2.Name = "btnnum2";
            this.btnnum2.Size = new System.Drawing.Size(145, 63);
            this.btnnum2.TabIndex = 8;
            this.btnnum2.Text = "Sair";
            this.btnnum2.UseVisualStyleBackColor = false;
            this.btnnum2.Click += new System.EventHandler(this.Btnnum2_Click);
            // 
            // btnnum3
            // 
            this.btnnum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnum3.Location = new System.Drawing.Point(157, 299);
            this.btnnum3.Name = "btnnum3";
            this.btnnum3.Size = new System.Drawing.Size(100, 63);
            this.btnnum3.TabIndex = 3;
            this.btnnum3.Text = "+";
            this.btnnum3.UseVisualStyleBackColor = true;
            this.btnnum3.Click += new System.EventHandler(this.Btnnum3_Click);
            // 
            // btnnum4
            // 
            this.btnnum4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnum4.Location = new System.Drawing.Point(288, 299);
            this.btnnum4.Name = "btnnum4";
            this.btnnum4.Size = new System.Drawing.Size(100, 63);
            this.btnnum4.TabIndex = 4;
            this.btnnum4.Text = "-";
            this.btnnum4.UseVisualStyleBackColor = true;
            this.btnnum4.Click += new System.EventHandler(this.Btnnum4_Click);
            // 
            // btnnum5
            // 
            this.btnnum5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnum5.Location = new System.Drawing.Point(413, 299);
            this.btnnum5.Name = "btnnum5";
            this.btnnum5.Size = new System.Drawing.Size(100, 63);
            this.btnnum5.TabIndex = 5;
            this.btnnum5.Text = "*";
            this.btnnum5.UseVisualStyleBackColor = true;
            this.btnnum5.Click += new System.EventHandler(this.Btnnum5_Click);
            // 
            // btnnum6
            // 
            this.btnnum6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnnum6.Location = new System.Drawing.Point(536, 299);
            this.btnnum6.Name = "btnnum6";
            this.btnnum6.Size = new System.Drawing.Size(100, 63);
            this.btnnum6.TabIndex = 6;
            this.btnnum6.Text = "/";
            this.btnnum6.UseVisualStyleBackColor = true;
            this.btnnum6.Click += new System.EventHandler(this.Btnnum6_Click);
            // 
            // txtnum3
            // 
            this.txtnum3.Enabled = false;
            this.txtnum3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtnum3.Location = new System.Drawing.Point(255, 217);
            this.txtnum3.Name = "txtnum3";
            this.txtnum3.Size = new System.Drawing.Size(170, 26);
            this.txtnum3.TabIndex = 2;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.txtnum3);
            this.Controls.Add(this.btnnum6);
            this.Controls.Add(this.btnnum5);
            this.Controls.Add(this.btnnum4);
            this.Controls.Add(this.btnnum3);
            this.Controls.Add(this.btnnum2);
            this.Controls.Add(this.lblnum3);
            this.Controls.Add(this.lblnum2);
            this.Controls.Add(this.txtnum2);
            this.Controls.Add(this.btnnum1);
            this.Controls.Add(this.lblnum1);
            this.Controls.Add(this.txtnum1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtnum1;
        private System.Windows.Forms.Label lblnum1;
        private System.Windows.Forms.Button btnnum1;
        private System.Windows.Forms.TextBox txtnum2;
        private System.Windows.Forms.Label lblnum2;
        private System.Windows.Forms.Label lblnum3;
        private System.Windows.Forms.Button btnnum2;
        private System.Windows.Forms.Button btnnum3;
        private System.Windows.Forms.Button btnnum4;
        private System.Windows.Forms.Button btnnum5;
        private System.Windows.Forms.Button btnnum6;
        private System.Windows.Forms.TextBox txtnum3;
    }
}

